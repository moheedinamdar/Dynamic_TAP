function txt = fixDetectorErrors(txt)

% This function replaces database entries that are known to be erroneous
% with the correct lines.

errors = {...
    '3263,16,N,34832,1,(4.649951,51.805161),Lane', '3263,16,N,34832,1,(4.649537,51.802441),Lane';
    '3264,16,N,34832,2,(4.649951,51.805161),Lane', '3264,16,N,34832,2,(4.649537,51.802441),Lane'};

for i=1:length(txt)
    j = 1;
    while j <= size(errors,1)
        if strcmp(txt{i}, errors{j,1})
            txt{i} = errors{j,2};
            errors(j,:) = [];
            j = size(errors,1);
        end
        j = j+1;
    end
end