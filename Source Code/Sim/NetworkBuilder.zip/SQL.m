function SQL(query)

% Perform an SQL command by creating an appropiate url for the Regiolab
% database and opening it in the default web browser.

% url safe characters
query = strrep(query, '=', '%3D');
query = strrep(query, '''', '%27');
query = strrep(query, ':', '%3A');

% surround query with url
url = ['http://www.regiolab-delft.nl/drupalsubmit/query.cgi?key=31&query=', ...
    query, '&format=csv&timeout=100000&retrieve=Submit+query'];

% open in web browser
web(url, '-browser');