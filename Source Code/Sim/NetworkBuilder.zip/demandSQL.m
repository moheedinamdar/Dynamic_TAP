function demandSQL(road, minDist, maxDist, minTime, maxTime)

% Creates and performs an SQL command based on the input.
%
% INPUT:
% road      Number of the road, e.g. '16' for A16.
% minDist   Minimum distance of required section (hecto sign, in meters).
% maxDist   Maximum distance of required section (hecto sign, in meters).
% minTime   Start time of required time span in the below format.
% maxTime   End time of required time span in the below format.
%
%               Time format: '2011-12-01 15:00:00'

query = ['SELECT rws_bps.key, minute, reliable, flow, speed FROM rws_bps_detections ', ... 
	'INNER JOIN rws_bps ON rws_bps_detections.bpskey = rws_bps.key ', ...
    'WHERE rws_bps.roadnumber = %r AND rws_bps.distance > %mind AND ', ...
    'rws_bps.distance < %maxd AND minute >= ''%mint'' ', ... 
    'AND minute < ''%maxt'' ORDER BY key, minute'];

query = strrep(query, '%r', num2str(road));
query = strrep(query, '%mind', num2str(minDist));
query = strrep(query, '%maxd', num2str(maxDist));
query = strrep(query, '%mint', minTime);
query = strrep(query, '%maxt', maxTime);

SQL(query);