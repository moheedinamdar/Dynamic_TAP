function runA16

% ATTENTION: The first time you run this, you may get the following error:
%
%   ??? Undefined function or variable 'jModel'.
%
% In that case, just run again. Calling javaaddpath does not seem to work
% straight away. If it still does not work, check that you are adding the 
% correct javapath. 

% Path where compiled java classes can be found
javapath = [cd '.\java\'];

% Add the java path so classes can be found by Matlab
javaaddpath(javapath);

% Import the required packages
import microModel.*;
import GUI.*;

% Create a model object
model = jModel;
model.dt = .5;
model.setSeed(0);
model.period = 3600*2;
model.debug = true;
model.settings.putBoolean('storeTrajectoryData', true);
model.settings.putBoolean('storeDetectorData', true);
model.settings.putString('outputDir', [cd '\output']);
startTime = '2009-05-13 15:00:00';
vec = datevec(startTime);
cal = java.util.Calendar.getInstance;
cal.set(vec(1), vec(2)-1, vec(3), vec(4), vec(5), vec(6));
model.startTime = cal.getTime;

% Load data to generate the network
net = kml2net(model, ...
    'A16 Drechttunnel map.kml',... network file
    -90,... rotation
    'detectors.txt',... detectors
    'data_13-05-2009.txt',... demand
    startTime,... start time
    model.period/60, ... simulation period
    true); ... verbose (give feedback)

% Note, the network file 'A16 Drechttunnel map.kml' has been created in
% Google Earth, so the required section numbers of demand locations are
% known. These can be used to produce route probabilities and class
% probabilities for certain lanes. Destination numbers can also be found
% through the section numbers.

% Offramp 21 demand of left freeway
split21_left = sum(sum(net.demand6)) / (sum(sum(net.demand4)) + sum(sum(net.demand6)));
% Offramp 21 demand of right freeway
split21_right = sum(sum(net.demand13)) / (sum(sum(net.demand9)) + sum(sum(net.demand13)));
% Offramp 20 demand
split20 = sum(sum(net.demand22)) / (sum(sum(net.demand19)) + sum(sum(net.demand22)));
% Fixed truck percentage
ptruck = .1; 
% Put all trucks on right lane of right highway (left highway is actually 
% prohibited for trucks)
ptruck_r = ptruck*(sum(sum(net.demand1))+sum(sum(net.demand7))) / sum(net.demand7(:,2));

% Create routes and set probabilities for routes and classes of left freeway
routesL = [jRoute(net.destination21) jRoute(net.destination6) jRoute(net.destination22)];
net.section1(1).generator.routes = routesL;
net.section1(1).generator.routeProb = [(1-split21_left)*(1-split20) split21_left (1-split21_left)*split20];
net.section1(1).generator.setClassProbabilities([1 0]);
net.section1(2).generator.routes = routesL;
net.section1(2).generator.routeProb = [(1-split21_left)*(1-split20) split21_left (1-split21_left)*split20];
net.section1(2).generator.setClassProbabilities([1 0]);

% Create routes and set probabilities for routes and classes of left freeway
routesR = [jRoute(net.destination21) jRoute(net.destination13) jRoute(net.destination22)];
net.section7(1).generator.routes = routesR;
net.section7(1).generator.routeProb = [(1-split21_right)*(1-split20) split21_right (1-split21_right)*split20];
net.section7(1).generator.setClassProbabilities([1 0]);
net.section7(2).generator.routes = routesR;
net.section7(2).generator.routeProb = [(1-split21_right)*(1-split20) split21_right (1-split21_right)*split20];
net.section7(2).generator.setClassProbabilities([1-ptruck_r ptruck_r]);

% Routes for onramp 21 at the right freeway
routes = [jRoute(net.destination21) jRoute(net.destination22)];
net.section14(1).generator.routes = routes;
net.section14(1).generator.routeProb = [1-split20 split20];
net.section14(1).generator.setClassProbabilities([1-ptruck ptruck]);

% Routes for onramp 20
% single route is not recognized as an array, create explicit java array
route = javaArray('microModel.jRoute', 1); 
route(1) = jRoute(net.destination21);
net.section23(1).generator.routes = route; % must be an array
net.section23(1).generator.routeProb = 1;
net.section23(1).generator.setClassProbabilities([1-ptruck ptruck]);

% Set vehicle-driver classes using the sub function
vehicleClasses(model);

% Initialize the model
model.init;

% Create a GUI around the model
gui = jModelGUI(model);

% Add a backdrop image
w = 3769;
gui.addBackdrop(imageBackdrop('backdrop.png', -38, -963, w, w/5));
gui.addPopupItem('Show backdrop', false); % backdrop on/off option

% Add 'time-to-collision' vehicle color
gui.addVehicleColor(TTC);

% Wait untill the simulation has (prematurely) ended
gui.waitFor

% Plot detector data around the merge taper and onramp 20
if model.settings.getBoolean('storeDetectorData')
    span = 5; % smooth span for data plot
    d = [char(model.settings.getString('outputDir')) '\detectors\'];
    
    % taper
    figure('NumberTitle', 'off', 'Name', 'Around taper');
    % upstream (left freeway)
    detR = jModel.loadDetectorData([d 'detector3284.dat']);
    detL = jModel.loadDetectorData([d 'detector3283.dat']);
    ax1 = subplot(2,3,1);
    set(ax1, 'Nextplot', 'add')
    plot(ax1, smooth(double(detR.q*60), span), 'Color', [0 0 1]);
    plot(ax1, smooth(double(detL.q*60), span), 'Color', [1 0 0]);
    plot(ax1, smooth(net.detector3284.q*60, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3283.q*60, span), 'Color', [1 0 0], 'LineStyle', ':');
    title('Upstream (left)')
    xlabel('Time [min]')
    ylabel('Flow [veh/h]')
    legend(ax1, 'Right lane', 'Left lane')
    ax2 = subplot(2,3,4);
    set(ax2, 'Nextplot', 'add')
    plot(ax2, smooth(double(detR.v*3.6), span), 'Color', [0 0 1]);
    plot(ax2, smooth(double(detL.v*3.6), span), 'Color', [1 0 0]);
    plot(ax2, smooth(net.detector3284.v, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3283.v, span), 'Color', [1 0 0], 'LineStyle', ':');
    xlabel('Time [min]')
    ylabel('Speed [km/h]')
    legend(ax2, 'Right lane', 'Left lane')
    
    % upstream (right freeway)
    detR = jModel.loadDetectorData([d 'detector3286.dat']);
    detL = jModel.loadDetectorData([d 'detector3285.dat']);
    ax1 = subplot(2,3,2);
    set(ax1, 'Nextplot', 'add')
    plot(ax1, smooth(double(detR.q*60), span), 'Color', [0 0 1]);
    plot(ax1, smooth(double(detL.q*60), span), 'Color', [1 0 0]);
    plot(ax1, smooth(net.detector3286.q*60, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3285.q*60, span), 'Color', [1 0 0], 'LineStyle', ':');
    title('Upstream (right)')
    xlabel('Time [min]')
    ylabel('Flow [veh/h]')
    legend(ax1, 'Right lane', 'Left lane')
    ax2 = subplot(2,3,5);
    set(ax2, 'Nextplot', 'add')
    plot(ax2, smooth(double(detR.v*3.6), span), 'Color', [0 0 1]);
    plot(ax2, smooth(double(detL.v*3.6), span), 'Color', [1 0 0]);
    plot(ax2, smooth(net.detector3286.v, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3285.v, span), 'Color', [1 0 0], 'LineStyle', ':');
    xlabel('Time [min]')
    ylabel('Speed [km/h]')
    legend(ax2, 'Right lane', 'Left lane')
    
    % downstream
    detR = jModel.loadDetectorData([d 'detector3295.dat']);
    detM = jModel.loadDetectorData([d 'detector3294.dat']);
    detL = jModel.loadDetectorData([d 'detector3293.dat']);
    ax1 = subplot(2,3,3);
    set(ax1, 'Nextplot', 'add')
    plot(ax1, smooth(double(detR.q*60), span), 'Color', [0 0 1]);
    plot(ax1, smooth(double(detM.q*60), span), 'Color', [0 1 0]);
    plot(ax1, smooth(double(detL.q*60), span), 'Color', [1 0 0]);
    plot(ax1, smooth(net.detector3295.q*60, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3294.q*60, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3293.q*60, span), 'Color', [1 0 0], 'LineStyle', ':');
    title('Downstream')
    xlabel('Time [min]')
    ylabel('Flow [veh/h]')
    legend(ax1, 'Right lane', 'Middle lane', 'Left lane')
    ax2 = subplot(2,3,6);
    set(ax2, 'Nextplot', 'add')
    plot(ax2, smooth(double(detR.v*3.6), span), 'Color', [0 0 1]);
    plot(ax2, smooth(double(detM.v*3.6), span), 'Color', [0 1 0]);
    plot(ax2, smooth(double(detL.v*3.6), span), 'Color', [1 0 0]);
    plot(ax2, smooth(net.detector3295.v, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3294.v, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3293.v, span), 'Color', [1 0 0], 'LineStyle', ':');
    xlabel('Time [min]')
    ylabel('Speed [km/h]')
    legend(ax2, 'Right lane', 'Middle lane', 'Left lane')
    
    % onramp 20 (bottleneck)
    figure('NumberTitle', 'off', 'Name', 'Around onramp 20');
    % upstream
    detR = jModel.loadDetectorData([d 'detector3325.dat']);
    detM = jModel.loadDetectorData([d 'detector3324.dat']);
    detL = jModel.loadDetectorData([d 'detector3323.dat']);
    ax1 = subplot(2,2,1);
    set(ax1, 'Nextplot', 'add')
    plot(ax1, smooth(double(detR.q*60), span), 'Color', [0 0 1]);
    plot(ax1, smooth(double(detM.q*60), span), 'Color', [0 1 0]);
    plot(ax1, smooth(double(detL.q*60), span), 'Color', [1 0 0]);
    plot(ax1, smooth(net.detector3325.q*60, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3324.q*60, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3323.q*60, span), 'Color', [1 0 0], 'LineStyle', ':');
    title('Upstream')
    xlabel('Time [min]')
    ylabel('Flow [veh/h]')
    legend(ax1, 'Right lane', 'Middle lane', 'Left lane')
    ax2 = subplot(2,2,3);
    set(ax2, 'Nextplot', 'add')
    plot(ax2, smooth(double(detR.v*3.6), span), 'Color', [0 0 1]);
    plot(ax2, smooth(double(detM.v*3.6), span), 'Color', [0 1 0]);
    plot(ax2, smooth(double(detL.v*3.6), span), 'Color', [1 0 0]);
    plot(ax2, smooth(net.detector3325.v, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3324.v, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3323.v, span), 'Color', [1 0 0], 'LineStyle', ':');
    xlabel('Time [min]')
    ylabel('Speed [km/h]')
    legend(ax2, 'Right lane', 'Middle lane', 'Left lane')
    % downstream
    detR = jModel.loadDetectorData([d 'detector3331.dat']);
    detM = jModel.loadDetectorData([d 'detector3330.dat']);
    detL = jModel.loadDetectorData([d 'detector3329.dat']);
    ax1 = subplot(2,2,2);
    set(ax1, 'Nextplot', 'add')
    plot(ax1, smooth(double(detR.q*60), span), 'Color', [0 0 1]);
    plot(ax1, smooth(double(detM.q*60), span), 'Color', [0 1 0]);
    plot(ax1, smooth(double(detL.q*60), span), 'Color', [1 0 0]);
    plot(ax1, smooth(net.detector3331.q*60, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3330.q*60, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax1, smooth(net.detector3329.q*60, span), 'Color', [1 0 0], 'LineStyle', ':');
    title('Downstream')
    xlabel('Time [min]')
    ylabel('Flow [veh/h]')
    legend(ax1, 'Right lane', 'Middle lane', 'Left lane')
    ax2 = subplot(2,2,4);
    set(ax2, 'Nextplot', 'add')
    plot(ax2, smooth(double(detR.v*3.6), span), 'Color', [0 0 1]);
    plot(ax2, smooth(double(detM.v*3.6), span), 'Color', [0 1 0]);
    plot(ax2, smooth(double(detL.v*3.6), span), 'Color', [1 0 0]);
    plot(ax2, smooth(net.detector3331.v, span), 'Color', [0 0 1], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3330.v, span), 'Color', [0 1 0], 'LineStyle', ':');
    plot(ax2, smooth(net.detector3329.v, span), 'Color', [1 0 0], 'LineStyle', ':');
    xlabel('Time [min]')
    ylabel('Speed [km/h]')
    legend(ax2, 'Right lane', 'Middle lane', 'Left lane')
end

% Sub function for the vehicle-driver classes
function vehicleClasses(model)

% Imports are function specific
import microModel.*;

% Car
% vehicle properties
veh1 = jVehicle(model);
veh1.l = 4;
veh1.vMax = 160;
veh1.marker = 'o';
veh1.aMin = -6;
% driver properties
jDriver(veh1);
veh1.driver.a = 1.25;
veh1.driver.b = 2.09;
veh1.driver.s0 = 3;
veh1.driver.Tmin = 0.56;
veh1.driver.Tmax = 1.2;
veh1.driver.dFree = 0.365;
veh1.driver.dSync = 0.577;
veh1.driver.dCoop = 0.788;
veh1.driver.vGain = 69.6/3.6;
veh1.driver.vCong = 60/3.6;
veh1.driver.bSafe = 2.09;
veh1.driver.tau = 25;
veh1.driver.x0 = 295;
veh1.driver.t0 = 43;
% create class object
defClass1 = jClass(model, veh1, 1);
% set stochastic properties
gauss = javaMethod('valueOf', 'microModel.jClass$distribution', 'GAUSSIAN');
defClass1.addStochasticDriverParameter('fSpeed', gauss, 123.7/120, 12/120);

% Truck
% vehicle properties
veh2 = jVehicle(model);
veh2.l = 14;
veh2.marker = 's';
veh2.aMin = -6;
% driver properties
jDriver(veh2);
veh2.driver.a = 0.4;
veh2.driver.b = 2.09;
veh2.driver.s0 = 3;
veh2.driver.Tmin = 0.56;
veh2.driver.Tmax = 1.2;
veh2.driver.fSpeed = 1;
veh2.driver.dFree = 0.365;
veh2.driver.dSync = 0.577;
veh2.driver.dCoop = 0.788;
veh2.driver.vGain = 69.6/3.6;
veh2.driver.vCong = 60/3.6;
veh2.driver.bSafe = 2.09;
veh2.driver.tau = 25;
veh2.driver.x0 = 295;
veh2.driver.t0 = 43;
% create class object
defClass2 = jClass(model, veh2, 2);
% set stochastic properties
defClass2.addStochasticVehicleParameter('vMax', gauss, 85, 2.5);