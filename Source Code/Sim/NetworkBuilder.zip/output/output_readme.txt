This folder is where the output is stored by default. Three subfolders may appear:

- detectors
Set of detector data files named detector#.dat where # is the detector id. These can be loaded using jModel.loadDetectorData(file).

- trajectories
Set of vehicle trajectory files called trajectory#.dat where # is a counter. These can be loaded using jModel.loadTrajectoryData(file).

- frames
Set of frames recorded from visualization called frame#.png where # is a counter. Use for example VirtualDub to create a movie from these frames.